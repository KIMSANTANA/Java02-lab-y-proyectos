/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Kimberly Santana
 */
public class Meses {
    static String[] meses = {
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    };
 
    static String[] estaciones = {
        "Invierno", "Invierno", "Primavera", "Primavera", "Primavera", "Verano",
        "Verano", "Verano", "Otono", "Otono", "Otono", "Invierno"
    };
    
    public static void main(String[]args){
    int[] numeros  = new int[4]};
    numeros [2] = 30;
    numeros [2] = 30;
    numeros [1] = 20;
    System.out.println(Arrays.toSring(numeros));
    
}
